import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

export default function TibetanMedicineLanding() {
  return (
    <div className="bg-white text-gray-800 font-sans">
      {/* Hero Section */}
      <section className="bg-[url('/images/tibetan-background.jpg')] bg-cover bg-center text-white py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h1
            className="text-4xl md:text-5xl font-bold mb-4"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            Помогаю исцеляться через знания тибетской медицины
          </motion.h1>
          <p className="text-lg md:text-xl mb-6">
            Диагностика, питание, чудлены, пилюли и мантры — по линии доктора Ниды Ченагцанга
          </p>
          <Button className="text-lg px-6 py-3 rounded-2xl shadow-lg">Записаться на консультацию</Button>
        </div>
      </section>

      {/* About Me */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Кто я</h2>
          <p className="text-lg mb-4">
            Меня зовут Таня. Я практик тибетской медицины, обучалась у доктора Ниды Ченагцанга, практикую в Лондоне и онлайн.
            В моей практике — аутентичные знания Сова Ригпа: травы, питание, диагностика по пульсу, чудлены и мантры.
          </p>
        </div>
      </section>

      {/* Services */}
      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-10">Чем я могу помочь</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              'Диагностика по пульсу и состоянию тела',
              'Подбор пилюль и рекомендации по приёму',
              'Тибетская диетология по дошам',
              'Чудлены и дыхательные практики',
              'Массаж и самомассаж',
              'Работа с мантрами и очищением каналов'
            ].map((service, index) => (
              <Card key={index} className="rounded-2xl shadow p-6">
                <CardContent>
                  <p className="text-lg">{service}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-gray-50 py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-10">Отзывы</h2>
          <div className="grid gap-6 md:grid-cols-2">
            {["После консультации с Таней я наконец-то поняла, как мне питаться, чтобы ушла тяжесть и бессонница.",
              "Пилюли и чудлены реально помогают — даже не ожидала! Тёплая, очень душевная атмосфера.",
              "Мне нравится, что всё по-настоящему. Ни эзотерики, ни фальши — всё чётко и с любовью."].map((quote, index) => (
              <Card key={index} className="p-6 rounded-2xl shadow">
                <CardContent>
                  <p className="italic">“{quote}”</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-16 px-4">
        <div className="max-w-xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-6">Связаться со мной</h2>
          <form className="space-y-4">
            <Input placeholder="Имя" />
            <Input placeholder="Email или Telegram" />
            <Textarea placeholder="Сообщение" rows={4} />
            <Button className="w-full py-3 rounded-2xl text-lg">Отправить</Button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-100 text-center text-sm py-6">
        <p className="mb-1">© 2025 Таня | Тибетская медицина по линии доктора Ниды</p>
        <p className="italic">«Слушай пульс — он знает больше, чем ум»</p>
      </footer>
    </div>
  );
}
